package data;

public enum Veil_Type {
partial, 
universal,
}
