package data;

public enum Gill_Attachment {
	attached,
	descending,
	free,
	notched,
}
