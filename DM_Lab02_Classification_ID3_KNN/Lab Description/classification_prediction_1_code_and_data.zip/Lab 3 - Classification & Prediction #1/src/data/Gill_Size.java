package data;

public enum Gill_Size {
broad,
narrow,
}
