package data;

public enum Cap_Surface {
	fibrous,
	grooves,
	scaly,
	smooth,
}
