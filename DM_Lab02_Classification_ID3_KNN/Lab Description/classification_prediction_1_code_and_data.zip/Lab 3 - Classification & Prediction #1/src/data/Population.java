package data;

public enum Population {
	abundant,
	clustered,
	numerous,
	scattered,
	several,
	solitary,
}
