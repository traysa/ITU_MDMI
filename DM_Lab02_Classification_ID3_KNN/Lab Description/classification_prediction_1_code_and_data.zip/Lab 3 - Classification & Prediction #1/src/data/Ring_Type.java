package data;

public enum Ring_Type {
	cobwebby,
	evanescent,
	flaring,
	large,
	none,
	pendant,
	sheathing,
	zone,
}
