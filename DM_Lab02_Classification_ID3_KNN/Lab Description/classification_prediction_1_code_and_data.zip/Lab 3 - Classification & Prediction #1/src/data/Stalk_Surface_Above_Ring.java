package data;

public enum Stalk_Surface_Above_Ring {
	ibrous,
	scaly,
	silky,
	smooth,
}
