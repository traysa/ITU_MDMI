package data;

public enum Stalk_Shape {
	enlarging,
	tapering,
}
