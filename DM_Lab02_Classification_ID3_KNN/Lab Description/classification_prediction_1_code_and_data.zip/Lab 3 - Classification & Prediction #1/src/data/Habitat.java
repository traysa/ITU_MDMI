package data;

public enum Habitat {
	grasses,
	leaves,
	meadows,
	paths,
	urban,
	waste,
	woods,
}
