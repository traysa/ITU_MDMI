package data;

public enum Bruises {
bruises,
no_bruises,
}
