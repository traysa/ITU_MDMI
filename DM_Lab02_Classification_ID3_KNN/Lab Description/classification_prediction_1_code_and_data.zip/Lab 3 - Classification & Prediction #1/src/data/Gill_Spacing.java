package data;

public enum Gill_Spacing {
	close,
	crowded,
	distant,
}
