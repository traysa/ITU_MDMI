package data;

public enum Ring_Number {
none,
one,
two, 
}
