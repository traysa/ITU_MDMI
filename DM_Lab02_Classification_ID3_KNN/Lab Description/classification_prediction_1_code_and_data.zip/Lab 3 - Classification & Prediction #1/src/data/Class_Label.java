package data;

public enum Class_Label {
	edible,
	poisonous,
 }
