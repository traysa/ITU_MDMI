package data;

public enum Veil_Color {
	brown,
	orange,
	white,
	yellow,
}
