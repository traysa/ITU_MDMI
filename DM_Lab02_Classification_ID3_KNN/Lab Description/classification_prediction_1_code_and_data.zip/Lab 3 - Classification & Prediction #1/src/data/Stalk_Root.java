package data;

public enum Stalk_Root {
	bulbous,
	club,
	cup,
	equal,
	rhizomorphs,
	rooted,
	missing,
}
