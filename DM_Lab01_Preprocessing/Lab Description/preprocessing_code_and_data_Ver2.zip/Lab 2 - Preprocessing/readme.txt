Info on the different data files

data_mining_2014_dataset:
CSV file containing the data from the questionnaires filled out by the 2014 Data Mining students (you!). 
"-" have been inserted when there is no value for an attribute.

Data_Mining_Student_DataSet_2013:
Original CSV file containing the data from the questionnaires filled out by the 2013 Data Mining students.
Empty string is used when there is no value for an attribute.
Some issues with this file:
Row 16 is invalid, due to a missing attribute ("noor_hometown" or "therb_fortt_glag".).
Row 35 is invalid, due to two missing attributes (english_level and fav_colour)

Data_Mining_Student_DataSet_2013_Fixed:
CSV file containing the data from the questionnaires filled out by the 2013 Data Mining students.
This file has been corrected for the above mentioned issues.
Many thanks to Niels Abildgaard for pointing out these issues and for helping correct them.
"-" have been inserted when there is no value for an attribute.