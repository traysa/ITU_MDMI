package data;
/**
 * Enum for the different iris classes.
 * @author Anders Hartzen, Jens Andersson Gr�n
 *
 */
public enum IrisClass {
	Iris_setosa,
	Iris_versicolor,
	Iris_virginica,	
}
